
require('./utils')
local log = io.open("podoboo-heights-1.csv", "w")
inputs = load_tas_file("podoboo-heights.tas")
local seed = prng_init()
frame_inputs = nil

emu.poweron()
for i=1,2649,1 do
    joypad.set(1, inputs[emu.framecount() - 1] or {})
    emu.frameadvance()
end
local start = savestate.object()
savestate.save(start)

local alignment_itc = {}
alignment_itc[1] = 18
alignment_itc[2] = 4
alignment_itc[3] = 11

for al=1,3 do
for rng=0,0x7FFE do
    frame_inputs = nil
    log:flush()
    savestate.load(start)
    seed = prng_advance(seed)
    memory.writebyte(IntervalTimerControl, alignment_itc[al])
    prng_apply(seed)

    for i=1,250,1 do
        joypad.set(1, inputs[emu.framecount() - 1] or {})
        emu.frameadvance()
    end
    log:write(string.format("%02X", EnemyY(2)))
end
end

log:close()
emu.pause()
