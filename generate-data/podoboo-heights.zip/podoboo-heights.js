const f = require('fs').readFileSync('./podoboo-heights-1.csv').toString();

const o = Buffer.alloc(f.length / 2);
for (let i=0; i<f.length; i+=2) {
    const v = parseInt(f.substring(i, i + 2), 16);
    o[i / 2] = v;
}
require('fs').writeFileSync('./podoboo-heights.bin', o);
